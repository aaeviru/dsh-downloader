import type { Preferences } from './preferences.ts';
import type { Context } from '@deepseek-ai/cordis';
import { TypertRemoteService } from '@deepseek-ai/dsh-typert-protocol';
import type Schema from '@deepseek-ai/schemastery';
import { Config } from './config.ts';
import type { DownloadService } from './service.ts';
import type { Candidate, RefreshResult, SubmitRecord, SubmitResult } from './types.ts';
export type { Config } from './config.ts';
/**
 * Resolve the submission store path.
 * @param storePath - absolute path, or one relative to the harness home.
 * @param env - environment carrying an optional `DSH_HOME` override.
 * @returns the absolute store path.
 */
export declare function resolveStorePath(storePath: string, env?: NodeJS.ProcessEnv): string;
/** Own the download service and its browser namespace. */
export declare class DownloadRemote extends TypertRemoteService {
    static inject: string[];
    /** Mount schema shared with the plugin entry. */
    static get Config(): Schema<Partial<Config>, Config>;
    /** The service the tools and the Remote methods share. */
    readonly service: Omit<DownloadService, 'submissions'>;
    private readonly ready;
    constructor(ctx: Context, config: Config);
    /**
     * Read committed search preferences.
     * @returns Committed preferences; persistence failures reject.
     */
    preferences(): Promise<Preferences>;
    /**
     * Record a successfully executed search without executing it again.
     * @param keyword - Exact keyword, with surrounding whitespace trimmed.
     * @returns Committed preferences; persistence failures reject.
     */
    recordSearch(keyword: string): Promise<Preferences>;
    /**
     * Toggle a saved keyword without searching or downloading.
     * @param keyword - Exact keyword, with surrounding whitespace trimmed.
     * @returns Committed preferences; persistence failures reject.
     */
    toggleFavorite(keyword: string): Promise<Preferences>;
    /**
     * Delete one history keyword while retaining favorites.
     * @param keyword - Exact keyword, with surrounding whitespace trimmed.
     * @returns Committed preferences; persistence failures reject.
     */
    deleteSearch(keyword: string): Promise<Preferences>;
    /**
     * Clear history while retaining favorites.
     * @returns Committed preferences; persistence failures reject.
     */
    clearHistory(): Promise<Preferences>;
    /**
     * Search candidates through the service for one keyword.
     * @param keyword - text matched against candidate titles.
     * @returns the matching candidates after deduplication.
     */
    search(keyword: string): Promise<readonly Candidate[]>;
    /**
     * List the cached candidates, discovering them on first use.
     * @returns the current candidate set.
     */
    list(): Promise<readonly Candidate[]>;
    /**
     * Submit one cached candidate to aria2.
     * @param candidateId - identifier from the current candidate set.
     * @returns the submission outcome, GID, timestamp, and call ID.
     */
    add(candidateId: string): Promise<SubmitResult>;
    /**
     * Read accepted submissions after store hydration.
     * @returns Records keyed by candidate dedupe key.
     */
    submissions(): Promise<readonly SubmitRecord[]>;
    /**
     * Explicitly submit a candidate again, preserving its old record on failure.
     * @param candidateId - Candidate identifier resolved by the service.
     * @returns The new gid or a pending/unsupported outcome.
     */
    resubmit(candidateId: string): Promise<SubmitResult>;
    /**
     * Read the state of one aria2 download.
     * @param gid - aria2 download identifier returned by a submission.
     * @returns the aria2-reported state for that GID.
     */
    status(gid: string): Promise<{
        state: string;
    }>;
    /**
     * Rediscover the last executed query without submitting downloads.
     * @returns the candidates and discovery counts; source failure preserves the previous cache.
     */
    refresh(): Promise<RefreshResult>;
}
//# sourceMappingURL=remote.d.ts.map